# Standup 2026-11-13

- Carrier outreach QA: 2 bugs left, both in time zone handling.
- Docs site at 70%.
- Load testing booked for the week of Nov 30.
