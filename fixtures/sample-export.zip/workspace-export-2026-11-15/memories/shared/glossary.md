# Glossary

- Exception: any shipment event that needs a human decision.
- Draft card: an outbound action waiting for human approval.
